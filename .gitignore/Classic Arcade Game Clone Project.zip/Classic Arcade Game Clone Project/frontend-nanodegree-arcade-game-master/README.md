frontend-nanodegree-arcade-game
===============================
Click [here](file:///D:/Udacity%20FEND/Classic%20Arcade%20Game%20Clone%20Project/frontend-nanodegree-arcade-game-master/index.html) to open the game.

#Project name is Facing enemies

##Description:
Here is my project of Classic Arcade Game. In this Game I use HTML, CSS and of course I use JavaScript. all of my work is on app.js

###Some links help me during buliding this project:
* To creat [canvas](https://classroom.udacity.com/nanodegrees/nd001-connect/parts/1176c8f3-2e61-42b9-8ae4-241dd3b123f6/modules/269645859775461/lessons/3163218691/concepts/31615887070923)
* This lessons are helping me to use [prototype class](https://classroom.udacity.com/nanodegrees/nd001-connect/parts/1176c8f3-2e61-42b9-8ae4-241dd3b123f6/modules/269645859775460/lessons/2794468538/concepts/27831285390923)
